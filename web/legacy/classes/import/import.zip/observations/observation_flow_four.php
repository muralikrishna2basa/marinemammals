<?php
/**
 * 	Observation importation tool v1.0.0
 *  Media Screen
 *  
 * 
 * 
 */
ob_start();

date_default_timezone_set('Europe/Paris');
$ese_seqno = $this->getThread();
$year = date('Ymd');
$img_dir = "uploads/$ese_seqno/"; 

require_once(Classes.'import/flow_class.php');
require_once(Functions.'Fixcoding.php');
include_once(Classes.'upload/upload_class.php');
include_once(Classes.'upload/Resize_class.php');

//  Set javascript & css files, to be loaded dynamically 
$css = "css/observation_flow_four.css";

$js = "js/observation_flow_four.js";

$upload = new Uploads($_SERVER['DOCUMENT_ROOT'].'/'.$img_dir,'Import.php');

// upload files
$upload->UploadFiles($img_dir);

$upload_rs =  new Resize($_SERVER['DOCUMENT_ROOT'].'/'.$img_dir,$_SERVER['DOCUMENT_ROOT'].'/'.$img_dir.'thumb/');

$upload_rs->setImageSize(50,50);

$auth = $this->auth;
$db = $this->db;
$val = $this->validation;
//$val->setStatus(false);
$val->set('button',$_POST['button'],'notChoose','Required');

if(isset($_POST['fileimgs']))
{
	$fileimgs = $_POST['fileimgs'];
}
else 
{
	$fileimgs = array();
}
// resize uploaded files
if($upload->hasUploaded())
{
	$upload_rs->resizeImg($upload->getUploadedFiles());
	
	$resizedfiles = $upload_rs->getResizedFiles();
	
	// insert resized files links to database s
	foreach($resizedfiles as $file)
	{
		$path_parts = pathinfo($file);
		$filename = $path_parts['filename'];
		$description = "uploaded via the observation importation tool";
		$psn_seqno = $auth->getSessionId();
		
		$mda_type = $path_parts['extension'];
		$location = $img_dir.'thumb/'.$file;
		
		$sql = "insert into medias(psn_seqno,description,mda_type,location,ese_seqno,display) values(:psn_seqno,:description,:mda_type,:location,:ese_seqno,0)";
		$binds = array(':psn_seqno'=>$psn_seqno,':description'=>$description,':mda_type'=>$mda_type,':location'=>$location,':ese_seqno'=>$ese_seqno);
		$db->query($sql,$binds);
 		if($db->isError()){ echo "<div class='errormessage'>$db->errormessage</div>";$val->setStatus(false);}
	}
	
	
}
echo $upload;
// display the images

$sql = "select * from medias where ese_seqno = :ese_seqno";
$bind = array(':ese_seqno'=>$ese_seqno);

$res = $db->query($sql,$bind);
if($db->isError()){ echo "<div class='errormessage'>$db->errormessage</div>"; $val->setStatus(false);}

?>
<form class='<?php echo $this->flowname.'_form';?>' method="POST" action='Import.php'> 
<fieldset>
<legend>Images</legend>
<?php
	while($row = $res->fetch())
	{
		$imgsrc = $row['LOCATION'];
		$path_parts = pathinfo($imgsrc);
		$basename = $path_parts['basename'];
		$filename = $path_parts['filename'];
		$display_row = $row['DISPLAY'];
		
		
		if(count($fileimgs)>0 && !in_array($imgsrc,$fileimgs))
		{
			// delete from database
			$sql = "delete from medias where ese_seqno = :ese_seqno and location = :location";
			$binds = array(':ese_seqno'=>$ese_seqno,':location'=>$imgsrc);
			$db->query($sql,$binds);
			if($db->isError()){ echo "<div class='errormessage'>delete unsuccessful</div>";$val->setStatus(false);}
			// delete thumbnail
			$old = getcwd(); // Save the current directory
    		chdir($_SERVER['DOCUMENT_ROOT']."/".$path_parts['dirname']);
    		unlink($basename);
    		chdir(".."); // go to the image folder and delete also the image
    		unlink($basename);
    		// 
			chdir($old); // Restore the old working directory    
		}		
		else 
		{
		if(isset($_POST[$filename]))
		{
			$val->setStatus(true);
		
			$display_row = $_POST[$filename];
			$sql ="update medias set display = :display where ese_seqno = :ese_seqno and location = :location";
			$binds = array(':display'=>$display_row,':ese_seqno'=>$ese_seqno,':location'=>$imgsrc);
			$db->query($sql,$binds);
			if($db->isError()){ echo "<div class='errormessage'>update unsuccessful</div>";$val->setStatus(false);}
		}
		$display = $display_row == 1?'checked="yes"':'';
		echo "<div class='block'><div class='button_tools'>
		<button class='del' type='button'><img alt='Del' src='/img/cross.png'></button>
		<input type='checkbox' class='img_select' name='img_select' $display/>
		<input style='display:none;' value='$display_row' class='checksave' name = '$filename'/>
		</div><div class='image'><input style='display:none;' name = 'fileimgs[]'value='$imgsrc'/><img alt='$filename' src='$imgsrc'></div></div>";
		}
	}
?>
<input style='display:none;' name = 'fileimgs[]'value=''/> 
</fieldset>
<?php echo "<div>".$this->getButtons()."</div>"; ?>
</form>
<?php
if($val->getStatus()){ob_end_clean();$this->navigate(); return;}

$tmp = ob_get_contents();

ob_end_clean();
		
$html = preg_replace("/\r?\n/", "\\n", addslashes($tmp)); 
$html = str_replace("\'","'",$html); // don't escape quotes i.e if \' => needed '
$html = fixEncoding($html);
//echo stripcslashes(json_encode(array('html'=>$html,'css'=>$css,'js'=>$js)));

echo "{\"html\":\"$html\",\"css\":\"$css\",\"js\":\"$js\",\"action\":\"observation_importation_tool\"}";
?>
